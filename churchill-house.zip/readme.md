# Churchill House

This folder contains the required text and imagery for the Churchill House website.

## Make sure you read the brief

The brief is available on the main GitHub page for the unit. Please read it before using this source content. 

## Questions?

Any questions/issues/comments etc? Please email your tutor or ask on Canvas. 